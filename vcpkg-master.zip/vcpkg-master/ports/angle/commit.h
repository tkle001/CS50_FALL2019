#define ANGLE_COMMIT_HASH "invalid-hash"
#define ANGLE_COMMIT_HASH_SIZE 12
#define ANGLE_COMMIT_DATE "invalid-date"
