---
name: Request a new port
about: Request a new port/library that vcpkg should support
title: "[New Port Request] <library name here>"
labels: new port request - consider making a PR!
assignees: ''

---

Library name:

Library description:

Source repository URL:

Project homepage (if different from the source repository):

Anything else that is useful to know when adding (such as optional features the library may have that should be included):
